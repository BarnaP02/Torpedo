#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <conio.h>
#include <time.h>
#include "Debug/debugmalloc.h"

//#define meret 26
//#define meret 24

typedef struct Pont {
    int x;
    int y;
}Pont;
typedef struct Hajo {
    Pont b;
    Pont e;
    int intact_tiles;   /*elej�n a haj� hossza, tal�latkor --, ha 0, akkor a haj� els�llyedt*/
}Hajo;
typedef struct Maptile {
    bool hit;
    char value;
}Maptile;
/*typedef struct Map {
    //Maptile terkep[26][26];     // enn�l nem lehet nagyobb t�rk�p
    Maptile** map_col;      //
}Map;*/
typedef struct State {
    Maptile **p1;
    Maptile **cp;
    Hajo p1navy[26];
    Hajo cpnavy[26];
}State;
typedef struct Game {
    int diff;
    int size;
    int gm;
    State s;
}Game;

void pull_out_the_cheats() {
    for (int i = 0; i < 260; i++)
    {
        printf("%3.d:%c\t", i, i);
    }
    printf("\n");
}

Maptile** mallocMap(size) {
    Maptile** mappp;
    mappp = (Maptile**)calloc(size, sizeof(Maptile*));
    for (int i = 0; i < size; i++)
    {
        mappp[i] = (Maptile*)calloc(size, sizeof(Maptile));
    }
    return mappp;
}
void freeMap(Maptile** mappp, int size) {
    for (int i = 0; i < size; i++)
    {
        free(mappp[i]);
    }
    free(mappp);
}

void set_type(char* ptype) {
    printf("LOAD/NEW (L/N)\n");
    char input;
    input = tolower(_getch());
    while (input != 'l' && input != 'n') {
        input = tolower(_getch());
    }
    *ptype = tolower(input);
}
void set_gm(char* pgm) {
    printf("Player vs Computer/Player vs Player (C/P)\n");
    char input;
    input = tolower(_getch());
    while (input != 'c' && input != 'p') {
        input = tolower(_getch());
    }
    *pgm = tolower(input);
}
void set_diff(char* pdiff) {
    printf("EASY/MEDIUM/HARD/EXTREME (E/M/H/X)\n");
    char input;
    input = tolower(_getch());
    while (input != 'e' && input != 'm' && input != 'h' && input != 'x') {
        input = tolower(_getch());
    }
    *pdiff = tolower(input);
}
void set_size(int * psize) {
    printf("SMALL/MEDIUM/BIG/HUGE (S/M/B/H)\n");
    char input;
    input = tolower(_getch());
    while (input != 's' && input != 'm' && input != 'b' && input != 'h') {
        input = tolower(_getch());
    }
    switch (input){
    case 's':
        *psize = 10;
        break;
    case 'm':
        *psize = 15;
        break;
    case 'b':
        *psize = 20;
        break;
    case 'h':
        *psize = 26;
        break;
    default:
        break;
    }
    //*psize = tolower(input);
}

bool placable(int rown, int col, char align, int index, int map_size, Hajo* new_navy, int navy_size) {  //meg kell n�zni hogy az eg�sz haj� rajta lenne e a p�ly�n (1) �s hogy nincs e t�l k�zel egy m�sik haj�hoz (2)
    Hajo ship;
    ship.b.x = col;
    ship.b.y = rown;       //mert egy nagy negat�v sz�m �s nem tal�lom hogy mi�rt
    ship.intact_tiles = index+1;        //mert carriern�l 4 lenne
    if (align=='v')
    {
        ship.e.x = col + index;
        ship.e.y = rown;
    }
    else
    {
        ship.e.x = col;
        ship.e.y = rown + index;
    }
    if (ship.e.x > map_size - 1 || ship.e.y > map_size - 1) //csak az endet tesztelem mert begininget �jra k�ri a f�ggv�ny ha nem megfelelel�
    {
        return false;
    }
    int this_ship_len = ((ship.e.x - ship.b.x) + (ship.e.y - ship.b.y)) % 256;
    Hajo that_ship;
    int that_ship_len = 0;
    for (int i = 0; i < navy_size; i++)
    {
        that_ship.b.x = new_navy[i].b.x;
        that_ship.b.y = new_navy[i].b.y;
        that_ship.e.x = new_navy[i].e.x;
        that_ship.e.y = new_navy[i].e.y;
        that_ship_len = ((new_navy[i].e.x - new_navy[i].b.x) + (new_navy[i].e.y - new_navy[i].b.y)) % 256;  //ha vizszintes akkor b.y �s e.y ugyan az, ha f�gg�leges akkor pedig a b.x �s e.x
        if (that_ship_len == 0) that_ship_len = -1;    //az �res haj�hoz nem kell hasonl�tani
        for (int i = 0; i < that_ship_len + 1; i++)     //v�gig megy�nk az �sszes mez�j�n a n�zend� haj�nak
        {
            for (int j = 0; j < this_ship_len + 1; j++)     //v�gign�zz�k az �sszes elem�t a haj�nak
            {
                if (ship.b.x==ship.e.x) //ha f�gg�leges
                {
                    if (that_ship.b.x == that_ship.e.x)  //ha f�gg�leges
                    {
                        if (abs(ship.b.x - that_ship.b.x) < 2 && abs((ship.b.y + j) - (that_ship.b.y + i)) < 2) {
                            return false;   //t�l k�zel vannak egym�shoz
                        }
                    }
                    else
                    {
                        if (abs(ship.b.x - (that_ship.b.x + i)) < 2 && abs((ship.b.y + j) - that_ship.b.y) < 2) {
                            return false;   //t�l k�zel vannak egym�shoz
                        }
                    }
                }
                else
                {
                    if (that_ship.b.x == that_ship.e.x)  //ha f�gg�leges
                    {
                        if (abs((ship.b.x + j) - that_ship.b.x) < 2 && abs(ship.b.y - (that_ship.b.y + i)) < 2) {
                            return false;   //t�l k�zel vannak egym�shoz
                        }
                    }
                    else
                    {
                        if (abs((ship.b.x + j) - (that_ship.b.x + i)) < 2 && abs(ship.b.y - that_ship.b.y) < 2) {
                            return false;   //t�l k�zel vannak egym�shoz
                        }
                    }
                }
            }
        }

    }
    printf("mukodik mert csodas\n");
    return true;
}
void get_ship_coords(char *rown, int *col, char *align, int index, int map_size) {
    printf("Hova keruljon egy %d hosszu hajo?\n", index+1);
    char row = tolower(_getch());
    *rown = row - 'a';
    printf("row:%c\trown:%d\n", row,*rown);
    printf("%c", row + ('A' - 'a'));
    char tempcol[3];
    gets(tempcol);
    tempcol[2] = '\0';
    if (strlen(tempcol)<2)
    {
        *col = tempcol[0] - '0' - 1;
        printf("col:%d\n",*col);
    }
    else
    {
        *col = (tempcol[0]-'0') * 10 + (tempcol[1] - '0') - 1;
        printf("col:%d\n", *col);
    }
    while (*rown<0 || *rown>map_size - 1 || *col<0 || *col>map_size - 1)
    {
        printf("rossz input\nrown:%d\ntempc:%s   coln:%d\nstrlen:%d\nHova keruljon egy %d hosszu hajo?\n", *rown, tempcol, *col, strlen(tempcol), index + 1);
        row = tolower(_getch());
        *rown = row - 'a';
        printf("--row:%c\trown:%d\n", row, *rown);
        printf("%c", row + ('A' - 'a'));
        gets(tempcol);
        if (strlen(tempcol) < 2)
        {
            *col = tempcol[0] - '0' - 1;
            printf("col:%d\n", *col);
        }
        else
        {
            *col = (tempcol[0] - '0') * 10 + (tempcol[1] - '0') - 1;
            printf("col:%d\n", *col);
        }
    }
    //*rown = *rown % 256;
    

    printf("Vizszintesen/Fuggolegesen (V/F)\n");
    *align = tolower(_getch());
    while (*align != 'v' && *align != 'f') {
        *align = tolower(_getch());
    }
    printf("align:%c\nkoord:%c%d [%d,%d]\n", *align + ('A' - 'a'), row + ('A' - 'a'), *col, *rown, *col);
    printf("++row:%c\trown:%d\n", row, *rown);
}
void place_ship(int* navy, int index, Hajo* new_navy, int map_size, int navy_size) {
    char row, align;
    int rown, col;
    get_ship_coords(&rown, &col, &align, index, map_size);
    rown = rown % 256;
    if (rown < 0) rown += 256;
    //printf("||rown:%d\tcol:%d\talign:%d\tindex:%d\tmapsize:%d\tnavy_size:%d\n", rown, col, align, index, map_size, navy_size);
    while (!placable(rown, col, align, index, map_size, new_navy, navy_size))
    {
        //printf("nem volt a palyan\n");
        printf("placable:%d\n", placable(rown, col, align, index, map_size, new_navy, navy_size));
        get_ship_coords(&rown, &col, &align, index, map_size);
        rown = rown % 256;
        if (rown < 0) rown += 256;
    }
    Hajo ship;
    ship.b.x = col;
    ship.b.y = rown;
    ship.intact_tiles = index + 1;
    if (align == 'v')
    {
        ship.e.x = col + index;
        ship.e.y = rown;
    }
    else
    {
        ship.e.x = col;
        ship.e.y = rown + index;
    }
    new_navy[navy_size-1] = ship;
}
void place_all_ships(int map_size, Hajo* new_navy) {
    int navy[5] = { 0 };    //hogy tudjuk hogy h�ny milyen haj� van
    switch (map_size)
    {
    case 10:
        navy[0] = 2;    //sub        (1x1)
        navy[1] = 2;    //destroyer  (2x1)
        navy[2] = 1;    //cruiser    (3x1)
        navy[3] = 1;    //battleship (4x1)
        navy[4] = 1;    //carrier    (5x1)
        break;
    case 15:
        navy[0] = 3;    //sub        (1x1)
        navy[1] = 3;    //destroyer  (2x1)
        navy[2] = 2;    //cruiser    (3x1)
        navy[3] = 2;    //battleship (4x1)
        navy[4] = 1;    //carrier    (5x1)
        break;
    case 20:
        navy[0] = 7;    //sub        (1x1)
        navy[1] = 5;    //destroyer  (2x1)
        navy[2] = 5;    //cruiser    (3x1)
        navy[3] = 4;    //battleship (4x1)
        navy[4] = 2;    //carrier    (5x1)
        break;
    case 26:
        navy[0] = 10;   //sub        (1x1)(az�rt csak t�z, mert m�r �gy is lehet egy teljes �r�t j�tszani, mivel hogy 676 mez�b�l �ll egy oldal)
        navy[1] = 11;   //destroyer  (2x1)
        navy[2] = 9;    //cruiser    (3x1)
        navy[3] = 7;    //battleship (4x1)
        navy[4] = 4;    //carrier    (5x1)
        break;
    default:
        break;
    }
    int index = 4;
    int navy_size = 0;
    for (int i = 4; i >= 0; i--)
    {
        while (navy[i] != 0) {
            navy_size++;
            place_ship(navy, i, new_navy, map_size, navy_size);
            navy[i]--;
        }
    }
}

void get_cp_ship_coords(int* rown, int* col, int* align, int index, int map_size) {
    *align = rand() % 2; //srand(time(0))
    if (align)      //f�gg�leges
    {
        *rown = rand() % (map_size - (index + 1)); //srand(time(0))
        *col = rand() % map_size; //srand(time(0))
    }
    else {
        *rown = rand() % map_size; //srand(time(0))
        *col = rand() % (map_size - (index + 1)); //srand(time(0))
    }
    printf("cp:[%d:%d] i:%d s:%d\n", *col, *rown,index, map_size);
}
void cp_place_ship(int* navy, int index, Hajo* new_navy, int map_size, int navy_size) {
    int rown, col, align;
    char alignc;
    get_cp_ship_coords(&rown, &col, &align, index, map_size);
    if (align) alignc = 'f';
    else alignc = 'v';
    while (!placable(rown, col, alignc, index, map_size,new_navy,  navy_size))
    {
        printf("placable:%d\n", placable(rown, col, alignc, index, map_size, new_navy, navy_size));
        get_cp_ship_coords(&rown, &col, &align, index, map_size);
        rown = rown % 256;
        if (rown < 0) rown += 256;
    }
    Hajo cp_ship;
    cp_ship.b.x = col;
    cp_ship.b.y = rown;
    cp_ship.intact_tiles = index + 1;
    if (align == 1)
    {
        cp_ship.e.x = col + index;
        cp_ship.e.y = rown;
    }
    else
    {
        cp_ship.e.x = col;
        cp_ship.e.y = rown + index;
    }
    new_navy[navy_size-1] = cp_ship;
}
void cp_place_all_ships(int map_size, Hajo* new_navy) {
    int navy[5] = { 0 };    //hogy tudjuk hogy h�ny milyen haj� van
    switch (map_size)
    {
    case 10:
        navy[0] = 2;    //sub        (1x1)
        navy[1] = 2;    //destroyer  (2x1)
        navy[2] = 1;    //cruiser    (3x1)
        navy[3] = 1;    //battleship (4x1)
        navy[4] = 1;    //carrier    (5x1)
        break;
    case 15:
        navy[0] = 3;    //sub        (1x1)
        navy[1] = 3;    //destroyer  (2x1)
        navy[2] = 2;    //cruiser    (3x1)
        navy[3] = 2;    //battleship (4x1)
        navy[4] = 1;    //carrier    (5x1)
        break;
    case 20:
        navy[0] = 7;    //sub        (1x1)
        navy[1] = 5;    //destroyer  (2x1)
        navy[2] = 5;    //cruiser    (3x1)
        navy[3] = 4;    //battleship (4x1)
        navy[4] = 2;    //carrier    (5x1)
        break;
    case 26:
        navy[0] = 10;   //sub        (1x1)(az�rt csak t�z, mert m�r �gy is lehet egy teljes �r�t j�tszani, mivel hogy 676 mez�b�l �ll egy oldal)
        navy[1] = 11;   //destroyer  (2x1)
        navy[2] = 9;    //cruiser    (3x1)
        navy[3] = 7;    //battleship (4x1)
        navy[4] = 4;    //carrier    (5x1)
        break;
    default:
        break;
    }
    int index = 4;
    int navy_size = 0;
    for (int i = 4; i >= 0; i--)
    {
        while (navy[i] != 0) {
            navy_size++;
            cp_place_ship(navy, i, new_navy, map_size, navy_size);
            navy[i]--;
        }
    }
}
void put_navy_on_map(Maptile** mappp,int map_size, Hajo* navy, int navy_size) {
    //printf("cso\n%d\n",navy_size);
    char c = 219;
    for (int i = 0; i < navy_size; i++)
    {
        int len = ((navy[i].e.x - navy[i].b.x) + (navy[i].e.y - navy[i].b.y)) % 256;
        for (int j = 0; j < len; j++)
        {
            //printf("cso1\n");
            if (navy[i].b.x == navy[i].e.x) //ha f�gg�leges
            {
                mappp[navy[i].b.x][navy[i].b.y + j].value = c;
            }
            else
            {
                mappp[navy[i].b.x + j][navy[i].b.y].value = c;            
            }
            mappp[navy[i].e.x][navy[i].e.y].value = c;
            //printf("%c", mappp[navy[i].b.x][navy[i].b.y].value);
        }
        if (navy[i].intact_tiles == 1) {
            //printf(".(%d:%d)\n", navy[i].b.x, navy[i].b.y);
            mappp[navy[i].b.x][navy[i].b.y].value = c;
        }
        //mappp[navy[len].e.x][navy[len].e.y].value = c;        
    }
    for (int i = 0; i < map_size; i++)
    {
        for (int j = 0; j < map_size; j++)
        {
            if (mappp[j][i].value != c)
            {
                mappp[j][i].value = 'v';
            }
            printf(".%c", mappp[j][i].value);
            mappp[i][j].hit = false;
        }
        printf("\n");
    }
}

void clear_navy(Hajo* navy, int len) {
    for (int i = 0; i < len; i++)
    {
        navy[i].b.x = -1;
        navy[i].b.y = -1;
        navy[i].e.x = -1;
        navy[i].e.y = -1;
        navy[i].intact_tiles = -1;
    }
}
int set_navy_size(int map_size) {
    switch (map_size)
    {
    case 10:
        return 7;
    case 15:
        return 11;
    case 20:
        return 23;
    case 26:
        return 41;
    default:
        return 0;
    }
}

void CPGame(char diff, int map_size) {
    Maptile **p1map = mallocMap(map_size), **cpmap = mallocMap(map_size);
    int len_of_navy = set_navy_size(map_size);
    printf("\n-_-_-navy_len:%d\n", len_of_navy);
    printf("\n-_-_-sizeof Hajo:%lu\tnavy:%lu\n", sizeof(Hajo), len_of_navy * sizeof(Hajo));
    Hajo* p1navy = (Hajo*)malloc(len_of_navy * sizeof(Hajo));
    if (p1navy == NULL) printf("itt a hiba\n");
    Hajo* cpnavy = (Hajo*)malloc(len_of_navy * sizeof(Hajo));
    if (cpnavy == NULL) printf("itt a hiba\n");
    clear_navy(p1navy,len_of_navy);
    place_all_ships(map_size, p1navy);
    clear_navy(cpnavy, len_of_navy);
    cp_place_all_ships(map_size, cpnavy);
    printf("Eternal Happiness\n");
    put_navy_on_map(p1map, map_size, p1navy, len_of_navy);
    put_navy_on_map(cpmap, map_size, cpnavy, len_of_navy);

    //ide j�n a folytat�s
    free(p1navy);
    free(cpnavy);
    freeMap(p1map, map_size);
    freeMap(cpmap, map_size);
}
void PvPGame(int map_size) {
    //Map p1map, p2map;
    int len_of_navy = set_navy_size(map_size);
    Hajo p1navy[41], p2navy[41];    //a legnagyobb p�ly�n 41 haj� van
    clear_navy(p1navy, len_of_navy);
    place_all_ships(map_size, p1navy);
    clear_navy(p2navy, len_of_navy);
    place_all_ships(map_size, p2navy);
    printf("Eternal Bliss\n");
}

void NewGame(char gamemode, char diff, int map_size) {
    //Maptile** Map = mallocMap(map_size);
    if (gamemode=='c')
    {
        CPGame(diff, map_size);
    }
    else
    {
        PvPGame(map_size);
    }
    //freeMap(Map,map_size);
}

int main()
{
    pull_out_the_cheats();
    printf("Hello world!\n");
    char type, gm, diff;
    int size;

    set_type(&type);
    if (type == 'n') {
        set_gm(&gm);
        set_size(&size);
        if (gm == 'c') {
            set_diff(&diff);
        }
        else {      //nincs �rtelme
            diff = 'b';
        }
    }
    else {          //beolvas�s lesz
        gm = 'a';
        diff = 'a';
    }
    NewGame(gm, diff, size);
    printf("type:%c\tgm:%c\tdiff:%c\n", type, gm, diff);
    return 0;
}
/*
* valtozas ami nagyon nagy
Napl�m:
11.06
amikor m�sodj�ra van megadva hib�san a haj� koordin�t�ja lehelyez�skor akkor egy v�gtelen loopba fut
j�l m�k�dik: tudja a program amikor olyan koordin�t�kat adunk meg amik nincsenek a t�rk�pen, figyelembe vaszi hogy mekkor�ra �ll�tjuk azt
pl small (10x10) p�ly�n nem hagyja hogy v5-re vagy a15-re rakjunk haj�t
m�g nem tud: megn�zni hogy lerakhat� e a haj�
�lom: tudja hogy r�rakn� e egy m�sik haj�ra vagy k�zvetlen�l mell�



11.07
Enn�l az outputn�l l�tszik, hogy a bet�s oszlopokat m�g nem kezeli j�l
LOAD/NEW (L/N)
Player vs Computer/Player vs Player (C/P)
SMALL/MEDIUM/BIG/HUGE (S/M/B/H)
EASY/MEDIUM/HARD/EXTREME (E/M/H/X)
Hova keruljon egy 5 hosszu hajo?
A8
Vizszintesen/Fuggolegesen (V/F)
align:V
koord:A8
mapsize:10
ship-end:A(-858993664) 12                   <--ez itt j� mert a 12 az kil�g a p�ly�r�l
placfals
nem volt a palyan
mapsize:10
ship-end:A(-858993664) 12
placfals
placable:0                                  <--ez nem m�k�dik m�g a bet�kkel
Hova keruljon egy 5 hosszu hajo?
G6
Vizszintesen/Fuggolegesen (V/F)
align:F
koord:G6
mapsize:10
ship-end:K(-858993654) 6                    <--itt a K az a 11. sor lenne (elvileg(m�g k�zpontos��tani k�ne hogy mi az x �s mi az y))
Hova keruljon egy 4 hosszu hajo?



11.8
Placable k�sz�l de nagyon sok a %256 mert nagy negat�v sz�mokat gyakran felvesznek v�ltoz�k
�jra k�ne �rni az eg�sz placable-t mert azon k�v�l j�
m�r nem hal meg ha nem sz�mot �runk be amikor azt k�r


11.9
Placable tov�bbra is k�sz�l. mer a sz�mok helyre vannak rakva de m�g nem m�k�dik j�l
Hova keruljon egy 5 hosszu hajo?

row:a   rown:0
A1
col:0
Vizszintesen/Fuggolegesen (V/F)
align:F
koord:A0 [0,0]
++row:a rown:0
||rown:0        col:0   align:102       index:4 mapsize:10      navy_size:1
rown:0  col:0   align:102       index:4 mapsize:10      navy_size:1
mapsize:10
ship-end:E(4) 0

this len:4      that len:0
mukodik mert csodas             <-itt lerakodott egy hajo A1-be f�gg�legesen
.
.
.
Hova keruljon egy 4 hosszu hajo?
row:c   rown:2
C1
col:0
Vizszintesen/Fuggolegesen (V/F)
align:F
koord:C0 [2,0]
++row:c rown:2
rown:2  col:0   align:102       index:3 mapsize:10      navy_size:2
mapsize:10
ship-end:F(5) 0

this len:3      that len:0

this len:3      that len:4
---------that:(0,0):(0,4)
i:0 j:0 this:(0,0)      that:(2,0)
.x:0 .y:2       i:0 j:1 this:(0,0)      that:(3,0)
.x:0 .y:3       i:0 j:2 this:(0,0)      that:(4,0)
.x:0 .y:4       i:0 j:3 this:(0,0)      that:(5,0)
.x:0 .y:5       ---------that:(0,0):(0,4)
i:1 j:0 this:(0,0)      that:(2,1)
.x:0 .y:3       i:1 j:1 this:(0,0)      that:(3,1)
.x:0 .y:4       i:1 j:2 this:(0,0)      that:(4,1)
.x:0 .y:5       i:1 j:3 this:(0,0)      that:(5,1)
.x:0 .y:6       ---------that:(0,0):(0,4)
i:2 j:0 this:(0,0)      that:(2,2)
.x:0 .y:4       i:2 j:1 this:(0,0)      that:(3,2)
.x:0 .y:5       i:2 j:2 this:(0,0)      that:(4,2)
.x:0 .y:6       i:2 j:3 this:(0,0)      that:(5,2)
.x:0 .y:7       ---------that:(0,0):(0,4)
i:3 j:0 this:(0,0)      that:(2,3)
.x:0 .y:5       i:3 j:1 this:(0,0)      that:(3,3)
.x:0 .y:6       i:3 j:2 this:(0,0)      that:(4,3)
.x:0 .y:7       i:3 j:3 this:(0,0)      that:(5,3)
.x:0 .y:8       ---------that:(0,0):(0,4)
i:4 j:0 this:(0,0)      that:(2,4)
.x:0 .y:6       i:4 j:1 this:(0,0)      that:(3,4)
.x:0 .y:7       i:4 j:2 this:(0,0)      that:(4,4)
.x:0 .y:8       i:4 j:3 this:(0,0)      that:(5,4)
.x:0 .y:9       mukodik mert csodas
Hova keruljon egy 3 hosszu hajo?                <--- �s itt l�tszik hogy nem j� �rt�k van a this-ben �s nem v�ltozik viszont a that mindk�t kordin�t�ja v�ltozik


*/
